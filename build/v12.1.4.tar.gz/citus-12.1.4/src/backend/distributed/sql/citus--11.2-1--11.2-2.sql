-- citus--11.2-1--11.2-2
#include "udfs/worker_adjust_identity_column_seq_ranges/11.2-2.sql"
