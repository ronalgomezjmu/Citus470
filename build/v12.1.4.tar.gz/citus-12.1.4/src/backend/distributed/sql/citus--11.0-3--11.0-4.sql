#include "udfs/citus_finish_pg_upgrade/11.0-4.sql"
