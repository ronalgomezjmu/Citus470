--  citus--8.1-1--8.2-1.sql

--  bump version to 8.2-1

