#include "udfs/citus_finish_pg_upgrade/10.2-4.sql"
