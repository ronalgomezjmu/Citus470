#include "../udfs/citus_finalize_upgrade_to_citus11/11.0-2.sql"
