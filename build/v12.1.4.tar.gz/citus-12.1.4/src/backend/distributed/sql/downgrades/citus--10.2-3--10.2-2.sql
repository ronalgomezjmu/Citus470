-- citus--10.2-3--10.2-2

#include "../../../columnar/sql/downgrades/columnar--10.2-3--10.2-2.sql"
