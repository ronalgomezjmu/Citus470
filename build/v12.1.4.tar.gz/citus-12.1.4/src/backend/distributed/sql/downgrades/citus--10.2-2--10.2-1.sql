-- citus--10.2-2--10.2-1

#include "../../../columnar/sql/downgrades/columnar--10.2-2--10.2-1.sql"
