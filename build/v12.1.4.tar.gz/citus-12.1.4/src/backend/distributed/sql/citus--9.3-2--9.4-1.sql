-- citus--9.3-2--9.4-1

-- bump version to 9.4-1
#include "udfs/worker_last_saved_explain_analyze/9.4-1.sql"
#include "udfs/worker_save_query_explain_analyze/9.4-1.sql"
