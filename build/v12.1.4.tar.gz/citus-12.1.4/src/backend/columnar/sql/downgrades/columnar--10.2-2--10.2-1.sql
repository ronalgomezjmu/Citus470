-- columnar--10.2-2--10.2-1.sql

-- grant read access for columnar.chunk to unprivileged user
GRANT SELECT ON columnar.chunk TO PUBLIC;
