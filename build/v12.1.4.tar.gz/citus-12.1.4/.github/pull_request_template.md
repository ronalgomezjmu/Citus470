DESCRIPTION: PR description that will go into the change log, up to 78 characters
